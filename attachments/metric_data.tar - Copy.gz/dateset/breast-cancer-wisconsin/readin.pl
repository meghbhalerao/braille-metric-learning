#! /usr/bin/perl

#open(IN, "breast-cancer-wisconsin.data");
open(IN, "wdbc.data");
open(OUT, ">wdbc.txt");


$count = 0;
$index = 0 - 1;
@labelname = "z";      # initialize label character list

while ($Line1 = <IN>) {
    @H = split(/,/, $Line1);
    $l = @H;  # length of each row
    chop($H[$l-1]);
    for ($i=1; $i<$l; $i++) {
	$matrix[$count][$i-1] = $H[$i];   
    }
    $count += 1;
#    if ($count == 1) {last;}

    if (isnew(\@labelname, $H[1])) {
	$index += 1;
	$labelname[$index] = $H[1];
    }
}

close TT;
@class_count = (0, 0);
for ($i=0; $i<$count; $i++) {
    for ($j=0; $j<=$index; $j++) {
	if ($labelname[$j] eq $matrix[$i][0]) {
	    $matrix[$i][0]=$j; 
	    $class_count[$j] += 1;
	}
    }
}
$nclass = $index+1;
print "counts = ".$count."\n";
print "number of class = ".$nclass."\n";
print "Class ";
for ($j=0; $j<=$index; $j++) {
    print "[".$j."] ".$class_count[$j]."    ";
}
print "\n";
&Print_matrix(\@matrix, OUT);         # output


# _______________________________
sub Print_matrix {
    local ($ref, $Fhandle, $i, $j, $N, $d);
    $ref = $_[0];
    $Fhandle = $_[1];
    $N = @$ref;
    $d = @{$$ref[0]};

    for ($i=0; $i<$N; $i++) {
	for ($j=0; $j<$d; $j++) {
	    print $Fhandle $$ref[$i][$j]." ";
	}
	print $Fhandle "\n";
    }
}

# _______________________________
sub isnew {
    local ($list, $ele, $i, $N, $indicator);
    $list = $_[0];
    $ele = $_[1];
    $N = @$list;
    $indicator = 1;
    
    for ($i=0; $i<=$N; $i++) {
	if ($N==0) {$indicator = 1;}
	elsif ($$list[$i] eq $ele) {$indicator = 0; $i=$N;}
    }
    $indicator;
}
